package com.accenture.lkm.business.bean;

public class BillRangeBean {
	private Double fromBill;
	private Double toBill;
	public Double getFromBill() {
		return fromBill;
	}
	public void setFromBill(Double fromBill) {
		this.fromBill = fromBill;
	}
	public Double getToBill() {
		return toBill;
	}
	public void setToBill(Double toBill) {
		this.toBill = toBill;
	}
	
}
