package com.accenture.lkm.business.bean;


public class CompliantTypeBean {
	private Integer compliantTypeId;
	private String compliantTypeName;
	public Integer getCompliantTypeId() {
		return compliantTypeId;
	}
	public void setCompliantTypeId(Integer compliantTypeId) {
		this.compliantTypeId = compliantTypeId;
	}
	public String getCompliantTypeName() {
		return compliantTypeName;
	}
	public void setCompliantTypeName(String compliantTypeName) {
		this.compliantTypeName = compliantTypeName;
	}
	
}
